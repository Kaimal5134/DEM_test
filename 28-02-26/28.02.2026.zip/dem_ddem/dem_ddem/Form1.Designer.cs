﻿namespace dem_ddem
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button_avtoriz = new Button();
            register = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // button_avtoriz
            // 
            button_avtoriz.Location = new Point(142, 309);
            button_avtoriz.Name = "button_avtoriz";
            button_avtoriz.Size = new Size(125, 36);
            button_avtoriz.TabIndex = 0;
            button_avtoriz.Text = "Войти";
            button_avtoriz.UseVisualStyleBackColor = true;
            button_avtoriz.Click += button_avtoriz_Click;
            // 
            // register
            // 
            register.Location = new Point(139, 351);
            register.Name = "register";
            register.Size = new Size(128, 36);
            register.TabIndex = 1;
            register.Text = "регистрация";
            register.UseVisualStyleBackColor = true;
            register.Click += register_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(142, 189);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(142, 252);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 27);
            textBox2.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(142, 166);
            label1.Name = "label1";
            label1.Size = new Size(43, 20);
            label1.TabIndex = 4;
            label1.Text = "login";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(142, 229);
            label2.Name = "label2";
            label2.Size = new Size(72, 20);
            label2.TabIndex = 5;
            label2.Text = "password";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(432, 485);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(register);
            Controls.Add(button_avtoriz);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "avtorization";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button_avtoriz;
        private Button register;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label1;
        private Label label2;
    }
}