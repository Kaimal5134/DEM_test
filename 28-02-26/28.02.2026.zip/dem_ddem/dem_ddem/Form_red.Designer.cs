﻿namespace dem_ddem
{
    partial class Form_red
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            label3 = new Label();
            comboBox_tovar = new ComboBox();
            comboBox_punkt = new ComboBox();
            comboBox_status = new ComboBox();
            label4 = new Label();
            label7 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(362, 454);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 0;
            button1.Text = "назад";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(173, 454);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 1;
            button2.Text = "сохранить";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(149, 123);
            label3.Name = "label3";
            label3.Size = new Size(49, 20);
            label3.TabIndex = 17;
            label3.Text = "товар";
            // 
            // comboBox_tovar
            // 
            comboBox_tovar.FormattingEnabled = true;
            comboBox_tovar.Location = new Point(149, 146);
            comboBox_tovar.Name = "comboBox_tovar";
            comboBox_tovar.Size = new Size(151, 28);
            comboBox_tovar.TabIndex = 18;
            // 
            // comboBox_punkt
            // 
            comboBox_punkt.FormattingEnabled = true;
            comboBox_punkt.Location = new Point(149, 211);
            comboBox_punkt.Name = "comboBox_punkt";
            comboBox_punkt.Size = new Size(151, 28);
            comboBox_punkt.TabIndex = 19;
            // 
            // comboBox_status
            // 
            comboBox_status.FormattingEnabled = true;
            comboBox_status.Location = new Point(149, 289);
            comboBox_status.Name = "comboBox_status";
            comboBox_status.Size = new Size(151, 28);
            comboBox_status.TabIndex = 21;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(149, 188);
            label4.Name = "label4";
            label4.Size = new Size(103, 20);
            label4.TabIndex = 22;
            label4.Text = "пункт выдачи";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(149, 262);
            label7.Name = "label7";
            label7.Size = new Size(103, 20);
            label7.TabIndex = 25;
            label7.Text = "статус заказа ";
            // 
            // Form_red
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(485, 513);
            Controls.Add(label7);
            Controls.Add(label4);
            Controls.Add(comboBox_status);
            Controls.Add(comboBox_punkt);
            Controls.Add(comboBox_tovar);
            Controls.Add(label3);
            Controls.Add(button2);
            Controls.Add(button1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form_red";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form_red";
            Load += Form_red_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Label label3;
        private ComboBox comboBox_tovar;
        private ComboBox comboBox_punkt;
        private ComboBox comboBox_status;
        private Label label4;
        private Label label7;
    }
}