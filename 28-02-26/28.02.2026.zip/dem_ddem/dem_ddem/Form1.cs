using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Google.Protobuf.Collections;
using MySql.Data.MySqlClient;

namespace dem_ddem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button_avtoriz_Click(object sender, EventArgs e)
        {
            string logUser = textBox1.Text;
            string pasUser = textBox2.Text;

            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("������� �����.", "����������", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (String.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("������� ������.", "����������", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            BD db = new BD();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            MySqlCommand commandAd = new MySqlCommand("SELECT * FROM `user` WHERE `Login` = @log AND `Password` = @pas", db.GetConneciton());
            commandAd.Parameters.Add("@log", MySqlDbType.VarChar).Value = logUser;
            commandAd.Parameters.Add("@pas", MySqlDbType.VarChar).Value = pasUser;
            adapter.SelectCommand = commandAd;
            adapter.Fill(table);
            if (table.Rows.Count == 1)
            {
                MessageBox.Show("����������� �������");
                this.Hide();
                main main = new main();
                main.Show();
            }
            else
            {
                MessageBox.Show("�������� ����� ��� ������");
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void register_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form_register ff = new Form_register();
            ff.Show();
        }
    }
}