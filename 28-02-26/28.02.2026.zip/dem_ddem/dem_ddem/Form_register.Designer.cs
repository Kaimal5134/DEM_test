﻿namespace dem_ddem
{
    partial class Form_register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label2 = new Label();
            label1 = new Label();
            textBox_pas = new TextBox();
            textBox_log = new TextBox();
            label3 = new Label();
            textBox_fio = new TextBox();
            button2 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(136, 349);
            button1.Name = "button1";
            button1.Size = new Size(134, 33);
            button1.TabIndex = 0;
            button1.Text = "регистрация";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(136, 192);
            label2.Name = "label2";
            label2.Size = new Size(72, 20);
            label2.TabIndex = 9;
            label2.Text = "password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(136, 129);
            label1.Name = "label1";
            label1.Size = new Size(43, 20);
            label1.TabIndex = 8;
            label1.Text = "login";
            // 
            // textBox_pas
            // 
            textBox_pas.Location = new Point(136, 215);
            textBox_pas.Name = "textBox_pas";
            textBox_pas.Size = new Size(125, 27);
            textBox_pas.TabIndex = 7;
            // 
            // textBox_log
            // 
            textBox_log.Location = new Point(136, 152);
            textBox_log.Name = "textBox_log";
            textBox_log.Size = new Size(125, 27);
            textBox_log.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(136, 250);
            label3.Name = "label3";
            label3.Size = new Size(31, 20);
            label3.TabIndex = 11;
            label3.Text = "FIO";
            // 
            // textBox_fio
            // 
            textBox_fio.Location = new Point(136, 273);
            textBox_fio.Name = "textBox_fio";
            textBox_fio.Size = new Size(125, 27);
            textBox_fio.TabIndex = 10;
            // 
            // button2
            // 
            button2.Location = new Point(297, 430);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 12;
            button2.Text = "Назад";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // Form_register
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(415, 486);
            Controls.Add(button2);
            Controls.Add(label3);
            Controls.Add(textBox_fio);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox_pas);
            Controls.Add(textBox_log);
            Controls.Add(button1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form_register";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form_register";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label2;
        private Label label1;
        private TextBox textBox_pas;
        private TextBox textBox_log;
        private Label label3;
        private TextBox textBox_fio;
        private Button button2;
    }
}