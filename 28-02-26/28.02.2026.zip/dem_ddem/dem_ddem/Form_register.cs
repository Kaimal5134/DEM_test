﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dem_ddem
{
    public partial class Form_register : Form
    {
        public Form_register()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 ff = new Form1();
            ff.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox_log.Text.Trim();
            string password = textBox_pas.Text.Trim();
            string fio = textBox_fio.Text.Trim();

            if (login == "" || password == "" || fio == "")
            {
                MessageBox.Show("Все поля должны быть заполнены!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            BD db = new BD();
            using (MySqlConnection conn = db.GetConneciton())
            {
                conn.Open();

                MySqlCommand checkCmd = new MySqlCommand("SELECT COUNT(*) FROM `user` WHERE `Login` = @log", conn);
                checkCmd.Parameters.AddWithValue("@log", login);
                int count = Convert.ToInt32(checkCmd.ExecuteScalar());
                if (count > 0)
                {
                    MessageBox.Show("Логин уже занят!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                MySqlCommand insertCmd = new MySqlCommand(
                    "INSERT INTO `user` (`id_role`, `Login`, `Password`, `FIO`) VALUES (3, @log, @pas, @fio)", conn);
                insertCmd.Parameters.AddWithValue("@log", login);
                insertCmd.Parameters.AddWithValue("@pas", password);
                insertCmd.Parameters.AddWithValue("@fio", fio);
                insertCmd.ExecuteNonQuery();
            }

            MessageBox.Show("Регистрация успешна!", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Hide();
            Form1 ff = new Form1();
            ff.Show();
        }
    }
}
