﻿using MySql.Data.MySqlClient;
using Mysqlx.Crud;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dem_ddem
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
            LoadOrders();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 ff = new Form1();
            ff.Show();
        }

        private void main_Load(object sender, EventArgs e)
        {

        }


        private void LoadOrders()
        {
            string query = @" SELECT  `Order`.id_order AS 'ID', `Order`.date_order AS 'Дата заказа',  `Order`.date_end AS 'Дата завершения',  `Order`.kod AS 'Код', Tovar.description AS 'Товар', user.fio AS 'ФИО', address.streat AS 'Улица', status_order.name AS 'Статус'  FROM `Order` LEFT JOIN Tovar ON `Order`.id_tovar = Tovar.idTovar LEFT JOIN user ON `Order`.fio = user.iduser LEFT JOIN address ON `Order`.id_punkt = address.idaddress   LEFT JOIN status_order ON `Order`.id_status = status_order.idstatus_order";

            using (var conn = new BD().GetConneciton())
            {
                conn.Open();
                var adapter = new MySqlDataAdapter(query, conn);
                var table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }

        private void button_red_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите заказ для редактирования");
                return;
            }

            int orderId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);

            Form_red editForm = new Form_red(orderId);
            if (editForm.ShowDialog() == DialogResult.OK)
            {

                LoadOrders();
            }
        }
    }
}
