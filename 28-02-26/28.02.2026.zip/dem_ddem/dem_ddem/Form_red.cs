﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dem_ddem
{
    public partial class Form_red : Form
    {
        private int _orderId;
        public Form_red(int orderId)
        {
            InitializeComponent();
            _orderId = orderId;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            main aa = new main();
            aa.Show();
        }

        private void Form_red_Load(object sender, EventArgs e)
        {
            using (var conn = new BD().GetConneciton())
            {
                conn.Open();

                DataTable dt;
           
                dt = new DataTable();
                new MySqlDataAdapter("SELECT idTovar, description FROM Tovar", conn).Fill(dt);
                comboBox_tovar.DataSource = dt;
                comboBox_tovar.DisplayMember = "description";
                comboBox_tovar.ValueMember = "idTovar";

                dt = new DataTable();
                new MySqlDataAdapter("SELECT idaddress, streat AS addr FROM address", conn).Fill(dt);
                comboBox_punkt.DataSource = dt;
                comboBox_punkt.DisplayMember = "addr";
                comboBox_punkt.ValueMember = "idaddress";


                dt = new DataTable();
                new MySqlDataAdapter("SELECT idstatus_order, name FROM status_order", conn).Fill(dt);
                comboBox_status.DataSource = dt;
                comboBox_status.DisplayMember = "name";
                comboBox_status.ValueMember = "idstatus_order";

                var cmd = new MySqlCommand("SELECT id_tovar, id_punkt, id_status FROM `Order` WHERE id_order = @id", conn);
                cmd.Parameters.AddWithValue("@id", _orderId);
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        comboBox_tovar.SelectedValue = reader["id_tovar"];
                        comboBox_punkt.SelectedValue = reader["id_punkt"];
                        comboBox_status.SelectedValue = reader["id_status"];
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox_tovar.SelectedValue == null || comboBox_punkt.SelectedValue == null || comboBox_status.SelectedValue == null)
            {
                MessageBox.Show("Заполните все поля");
                return;
            }

            using (var conn = new BD().GetConneciton())
            {
                conn.Open();
                var cmd = new MySqlCommand(
                    "UPDATE `Order` SET id_tovar = @tovar, id_punkt = @punkt, id_status = @status WHERE id_order = @id",
                    conn);
                cmd.Parameters.AddWithValue("@tovar", comboBox_tovar.SelectedValue);
                cmd.Parameters.AddWithValue("@punkt", comboBox_punkt.SelectedValue);
                cmd.Parameters.AddWithValue("@status", comboBox_status.SelectedValue);
                cmd.Parameters.AddWithValue("@id", _orderId);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Сохранено");
            DialogResult = DialogResult.OK;
            Close();
        }
    }
    }

