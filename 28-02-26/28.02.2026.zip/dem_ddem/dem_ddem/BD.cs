﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace dem_ddem
{
    internal class BD
    {
        MySqlConnection connection = new MySqlConnection("server=cfif31.ru; port=3306; username=ISPr25-21_TimofeevKO; password=ISPr25-21_TimofeevKO; database=ISPr25-21_TimofeevKO_gggg  ");

        public void OnepConnection()
        {
            if (connection.State == System.Data.ConnectionState.Closed) connection.Open();
        }
        public void CloseConnection()
        {
            if(connection.State == System.Data.ConnectionState.Open) connection.Close();

        }
        public MySqlConnection GetConneciton()
        {
            return connection;
        }
    }
}
